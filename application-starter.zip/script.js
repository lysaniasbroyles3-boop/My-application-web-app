document.addEventListener("DOMContentLoaded", () => {
    const statusText = document.getElementById("status-text");
    const actionBtn = document.getElementById("action-btn");

    statusText.textContent = "JavaScript is connected and working perfectly!";

    actionBtn.addEventListener("click", () => {
        alert("Hello! Your application is fully interactive.");
    });
});
